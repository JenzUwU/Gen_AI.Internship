import os
print("Python running from folder:", os.getcwd())

import numpy as np  # for array work

def get_grade(total):
    # giving grade based on total
    if total >= 70:
        return "A"
    elif total >= 60:
        return "B"
    elif total >= 50:
        return "C"
    elif total >= 40:
        return "D"
    else:
        return "F"

try:
    # reading file
    inp_file = "students_input.txt"   # file must be in same folder
    out_file = "students_output.txt"

    stu_list = []  # empty list to store data

    with open(inp_file, "r") as f:
        for line in f:
            bits = line.strip().split(",")  # split values by comma

            if len(bits) != 3:
                print("Bad line skipped:", line)
                continue

            reg, exam_m, cw_m = bits

            try:
                exam_m = float(exam_m)
                cw_m = float(cw_m)
            except:
                print("Marks not number, skipping:", line)
                continue

            # calc total
            total = (exam_m * 0.7) + (cw_m * 0.3)

            # grade
            grd = get_grade(total)

            stu_list.append((reg, exam_m, cw_m, total, grd))

    # making numpy array
    dtype = [
        ("reg", "U20"),
        ("exam", float),
        ("cw", float),
        ("total", float),
        ("grade", "U2")
    ]

    stu_arr = np.array(stu_list, dtype=dtype)

    # sorting by total
    stu_arr = np.sort(stu_arr, order="total")[::-1]  # highest first

    # write to output file
    with open(out_file, "w") as f:
        f.write("RegNo,Exam,Coursework,Total,Grade\n")
        for row in stu_arr:
            f.write(f"{row['reg']},{row['exam']},{row['cw']},{row['total']:.2f},{row['grade']}\n")

    # grade count
    print("Grade Report:")
    grades = ["A","B","C","D","F"]
    for g in grades:
        cnt = np.sum(stu_arr["grade"] == g)
        print(f"{g}: {cnt}")

    print("\nDone! Output saved in:", out_file)

except FileNotFoundError:
    print("File not found! Please check the input filename.")

except Exception as e:
    print("Some error came:", e)
