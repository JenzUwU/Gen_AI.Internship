import datetime #importing datetime library to use date functionalities

def main():
    print("Age Calculator")
    print("ENTER YOUR DOB IN MM/DD/YYYY METHOD")

    try:
        # getting dob from user
        u_input = input("ENTER YOUR DOB (mm/dd/yyyy): ").strip()
        try:
            birthdate = datetime.datetime.strptime(u_input, "%m/%d/%Y").date()
        except ValueError:
            raise ValueError("Invalid date! Please follow mm/dd/yyyy format and enter a correct date.")
        # today date for age calc
        today = datetime.date.today()
        # calc basic age
        age = today.year - birthdate.year
        #if birthday not over yet minus 1 value from age 
        if (today.month, today.day) < (birthdate.month, birthdate.day):
            age -= 1
        # Converting date into dd/mm/yyyy (European style)
        european_format = birthdate.strftime("%d/%m/%Y")
        # displays res
        print(f"Your birthdate in European format is: {european_format}")
        print(f"Your current age is: {age} years")
        
    except Exception as error:
        # error handling
        print("Error:", error)
    # conclusion
    print("/n")
    print("Conclusion: Thank you for using the Age Calculator!")

if __name__ == "__main__":
    main()
