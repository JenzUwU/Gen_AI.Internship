
import requests  # to call API
import datetime  # for date/time stamp

# function to get weather from API
def fetch_weather(city, api_key):
    try:
        url = f"https://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}&units=metric"  # making API link
        res = requests.get(url)  # calling API

        if res.status_code != 200:  # if wrong city or wrong key
            print("City name wrong or API key wrong")
            return None

        return res.json()  # sending back weather data

    except Exception as e:
        print("Network problem:", e)  # if internet issue
        return None

# function to analyze temperature, wind, humidity
def analyze_weather(wdata):
    try:
        temp = wdata["main"]["temp"]  # reading temp
        wind = wdata["wind"]["speed"]  # reading wind speed
        hum = wdata["main"]["humidity"]  # reading humidity

        if temp <= 10:
            msg = "Cold (≤10°C)"
        elif 11 <= temp <= 24:
            msg = "Mild (11–24°C)"
        else:
            msg = "Hot (≥25°C)"

        if wind > 10:
            msg += " | High wind alert!"  # extra warning

        if hum > 80:
            msg += " | Humid conditions!"  # extra warning

        return msg

    except:
        return "Missing data in API response"

# saving info inside CSV file
def log_weather(city, filename, api_key):
    wdata = fetch_weather(city, api_key)  # get data

    if wdata is None:  # if fetch failed
        print("Weather not fetched")
        return

    summary = analyze_weather(wdata)  # analyze

    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")  # time stamp

    temp = wdata["main"]["temp"]  # required fields
    wind = wdata["wind"]["speed"]
    hum = wdata["main"]["humidity"]

    try:
        with open(filename, "a") as f:  # opening CSV
            f.write(f"{now},{city},{temp},{wind},{hum},{summary}\n")  # writing one line

        print("Weather saved in", filename)

    except Exception as e:
        print("File saving issue:", e)

# running program
if __name__ == "__main__":
    print("Weather Program Running...")
    city_name = input("Enter city name: ")  # user city input
    api_key = input("Enter your API key: ")  # user API key
    log_weather(city_name, "weather_log.csv", api_key)
