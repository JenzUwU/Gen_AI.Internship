# Exercise 2: Prime Number Generator
def is_prime(n):
    if n <= 1:  # not prime
        return False
    for i in range(2, int(n**0.5) + 1):  # check factors
        if n % i == 0:
            return False
    return True  # prime

def main():
    print("Intro: This program shows prime numbers in a range.")
    try:
        start = input("Enter start number: ").strip()
        end = input("Enter end number: ").strip()
        try:
            start = int(start)
            end = int(end)
        except:
            raise ValueError("Only whole numbers allowed.")
        if start <= 0 or end <= 0:
            raise ValueError("Numbers must be positive.")
        if start > end:
            raise ValueError("Start must be smaller than end.")
        primes = []
        for num in range(start, end + 1):
            if is_prime(num):
                primes.append(num)
        print("Prime numbers:")
        count = 0
        for p in primes:
            print(p, end="  ")
            count += 1
            if count == 10:  # 10 per line
                print()
                count = 0
        print()
    except Exception as e:
        print("Error:", e)
    print("Conclusion: Done.")

if __name__ == "__main__":
    main()
